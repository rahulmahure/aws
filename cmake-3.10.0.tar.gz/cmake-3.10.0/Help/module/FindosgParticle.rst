.. cmake-module:: ../../Modules/FindosgParticle.cmake
